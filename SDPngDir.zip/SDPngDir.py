import os
import sys
from PIL import Image
import json

def dir_to_json(directory):
    result = {}
    
    for item in os.listdir(directory):
        item_path = os.path.join(directory, item)
        if os.path.isdir(item_path):
            result[item] = dir_to_json(item_path)  # Recursively handle directories
        elif os.path.isfile(item_path):
            with open(item_path, "rb") as f:
                binary_content = f.read()
                hex_content = binary_content.hex()
                result[item] = hex_content  # Store file content as hex
    
    return result

def json_to_binary(json_data):
    json_string = json.dumps(json_data)
    binary_string = ''.join(format(ord(char), '08b') for char in json_string)
    return binary_string

def binary_to_dir(binary_data, output_dir):
    json_string = ''.join(chr(int(binary_data[i:i+8], 2)) for i in range(0, len(binary_data), 8))
    json_data = json.loads(json_string)
    os.makedirs(output_dir, exist_ok=True)
    recreate_structure(json_data, output_dir)

def recreate_structure(json_data, output_dir):
    for key, value in json_data.items():
        if isinstance(value, dict):
            dir_path = os.path.join(output_dir, key)
            os.makedirs(dir_path, exist_ok=True)
            recreate_structure(value, dir_path)
        else:
            file_path = os.path.join(output_dir, key)
            with open(file_path, 'wb') as f:
                f.write(bytes.fromhex(value))

def compress(source_dir, output_file, width, height, style_file=None):
    if style_file:
        with open(style_file, "r") as file:
            style = json.load(file)
    else:
        style = {
            "UNUSED": "(153, 148, 148)",
            "0": "(153, 147, 148)",
            "1": "(153, 149, 148)"
        }

    directory_structure = dir_to_json(source_dir)
    binary_data = json_to_binary(directory_structure)

    img = Image.new("RGB", (int(width), int(height)), tuple(map(int, style["UNUSED"].strip("()").split(","))))
    pixels = img.load()
    
    idx = 0
    for y in range(img.height):
        for x in range(img.width):
            if idx < len(binary_data):
                bit = binary_data[idx]
                if bit == '0':
                    pixels[x, y] = tuple(map(int, style["0"].strip("()").split(",")))
                elif bit == '1':
                    pixels[x, y] = tuple(map(int, style["1"].strip("()").split(",")))
                idx += 1
            else:
                pixels[x, y] = tuple(map(int, style["UNUSED"].strip("()").split(",")))

    img.save(output_file)
    print(f"Compressed directory '{source_dir}' into PNG file '{output_file}'")

def decompress(png_file, output_dir, style_file=None):
    if style_file:
        with open(style_file, "r") as file:
            style = json.load(file)
    else:
        style = {
            "UNUSED": "(153, 148, 148)",
            "0": "(153, 147, 148)",
            "1": "(153, 149, 148)"
        }
    
    img = Image.open(png_file)
    pixels = img.load()

    binary_data = []
    
    for y in range(img.height):
        for x in range(img.width):
            pixel = pixels[x, y]
            if pixel == tuple(map(int, style["0"].strip("()").split(","))):
                binary_data.append('0')
            elif pixel == tuple(map(int, style["1"].strip("()").split(","))):
                binary_data.append('1')

    binary_string = ''.join(binary_data)
    binary_to_dir(binary_string, output_dir)
    print(f"Decompressed PNG '{png_file}' into directory '{output_dir}'")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage:")
        print("  python sdpngdir.py compress <source_dir> <output_file.png> <width> <height> [<style_file.json>]")
        print("  python sdpngdir.py decompress <input_file.png> <output_dir> [<style_file.json>]")
        sys.exit(1)

    action = sys.argv[1]
    if action == "compress":
        source_dir = sys.argv[2]
        output_file = sys.argv[3]
        width = sys.argv[4]
        height = sys.argv[5]
        style_file = sys.argv[6] if len(sys.argv) > 6 else None
        compress(source_dir, output_file, width, height, style_file)
    elif action == "decompress":
        png_file = sys.argv[2]
        output_dir = sys.argv[3]
        style_file = sys.argv[4] if len(sys.argv) > 4 else None
        decompress(png_file, output_dir, style_file)
    else:
        print("Unknown action:", action)
        sys.exit(1)
