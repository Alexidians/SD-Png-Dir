import easygui
import os
import subprocess
import sys

def generate_command():
    operation = easygui.buttonbox("Select Operation", choices=["Compress", "Decompress"])
    
    if operation == "Compress":
        source_dir = easygui.diropenbox("Select Directory to Compress")
        if not source_dir:
            easygui.msgbox("No directory selected!", "Error")
            return
        
        output_file = easygui.filesavebox("Select PNG Output File", default="output.png", filetypes=["*.png"])
        if not output_file:
            easygui.msgbox("No output file selected!", "Error")
            return
        
        width = easygui.enterbox("Enter Image Width")
        if not width.isdigit():
            easygui.msgbox("Width must be a number!", "Error")
            return
        
        height = easygui.enterbox("Enter Image Height")
        if not height.isdigit():
            easygui.msgbox("Height must be a number!", "Error")
            return
        
        style_file = easygui.fileopenbox("Select Style JSON (optional)", filetypes=["*.json"])
        
        command = ["python", "sdpngdir.py", "compress", source_dir, output_file, width, height]
        if style_file:
            command.append(style_file)
    
    elif operation == "Decompress":
        png_file = easygui.fileopenbox("Select PNG File to Decompress", filetypes=["*.png"])
        if not png_file:
            easygui.msgbox("No PNG file selected!", "Error")
            return
        
        output_dir = easygui.diropenbox("Select Output Directory for Decompression")
        if not output_dir:
            easygui.msgbox("No directory selected!", "Error")
            return
        
        style_file = easygui.fileopenbox("Select Style JSON (optional)", filetypes=["*.json"])
        
        command = ["python", "sdpngdir.py", "decompress", png_file, output_dir]
        if style_file:
            command.append(style_file)
    
    else:
        easygui.msgbox("No operation selected!", "Error")
        return
    
    result = easygui.buttonbox(f"Generated Command:\n{' '.join(command)}", "Command Generated", choices=["Execute", "Cancel"])
    
    if result == "Execute":
        try:
            subprocess.run([sys.executable] + command[1:], check=True)
            easygui.msgbox("Command executed successfully!", "Success")
        except subprocess.CalledProcessError as e:
            easygui.msgbox(f"Error executing command:\n{e}", "Error")
    else:
        easygui.msgbox("Command not executed.")

if __name__ == "__main__":
    generate_command()
